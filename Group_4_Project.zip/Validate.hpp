/**************************************************************************
** Program name: Lab 4
** Author: Zachary Khan
** Date: 4/29/2018
** Description: The hpp file for my validate function
**************************************************************************/


#ifndef VALIDATE_HPP
#define VALIDATE_HPP

void Validate(int&,int, int);

#endif